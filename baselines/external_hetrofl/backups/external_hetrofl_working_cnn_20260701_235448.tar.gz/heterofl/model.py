import torch
import torch.nn as nn


def _scaled_channels(base_channels, model_rate):
    return [max(1, int(c * model_rate)) for c in base_channels]


class HeteroCifarCNN(nn.Module):
    def __init__(self, model_rate=1.0, num_classes=10):
        super().__init__()

        c1, c2, c3 = _scaled_channels([64, 128, 256], model_rate)

        self.features = nn.Sequential(
            nn.Conv2d(3, c1, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(c1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),

            nn.Conv2d(c1, c2, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(c2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),

            nn.Conv2d(c2, c3, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(c3),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((1, 1)),
        )

        self.classifier = nn.Linear(c3, num_classes)

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        return self.classifier(x)


def create_model(model_rate=1.0, num_classes=10):
    return HeteroCifarCNN(model_rate=model_rate, num_classes=num_classes)
